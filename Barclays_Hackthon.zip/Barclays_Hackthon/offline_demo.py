import streamlit as st
import torch
from transformers import AutoTokenizer, AutoModelForSequenceClassification


st.set_page_config(
    page_title="FraudLens – Fraud Detection",
    page_icon="🔐",
    layout="wide"
)


st.markdown("""
<style>
body { background-color: #f6f8fb; }

.block-container {
    padding-top: 2.2rem;
    padding-bottom: 2rem;
}

/* Cards */
.card {
    background: #ffffff;
    border-radius: 10px;
    padding: 18px 22px;
    border: 1px solid #e5e9f2;
    margin-bottom: 18px;
}

/* Header */
.app-title {
    font-size: 30px;
    font-weight: 600;
    color: #0f172a;
}
.app-subtitle {
    font-size: 14px;
    color: #64748b;
    margin-top: 4px;
}

/* Section titles */
.section-title {
    font-size: 15px;
    font-weight: 600;
    color: #334155;
    margin-bottom: 6px;
}

/* Risk badges */
.badge-low {
    background: #dcfce7;
    color: #166534;
    padding: 6px 16px;
    border-radius: 999px;
    font-size: 13px;
    font-weight: 600;
}
.badge-medium {
    background: #fef3c7;
    color: #92400e;
    padding: 6px 16px;
    border-radius: 999px;
    font-size: 13px;
    font-weight: 600;
}
.badge-high {
    background: #fee2e2;
    color: #991b1b;
    padding: 6px 16px;
    border-radius: 999px;
    font-size: 13px;
    font-weight: 600;
}

/* Explanation text */
.explain {
    font-size: 14px;
    color: #334155;
}

/* Footer */
.footer {
    text-align: center;
    color: #94a3b8;
    font-size: 12px;
    margin-top: 34px;
}
</style>
""", unsafe_allow_html=True)


MODEL_PATH = "./barclays_ai_phishing/fast_ai_phishing_model"

@st.cache_resource
def load_model():
    tokenizer = AutoTokenizer.from_pretrained(
        MODEL_PATH, local_files_only=True
    )
    model = AutoModelForSequenceClassification.from_pretrained(
        MODEL_PATH, local_files_only=True
    )
    model.eval()
    return tokenizer, model

tokenizer, model = load_model()

def predict(text):
    inputs = tokenizer(
        text,
        return_tensors="pt",
        truncation=True,
        padding="max_length",
        max_length=64
    )
    with torch.no_grad():
        outputs = model(**inputs)
    return torch.softmax(outputs.logits, dim=1).squeeze().tolist()

def decide_label(probs):
    legit, human, ai = probs

    if legit >= 0.75 and max(human, ai) < 0.2:
        return "Legitimate Email", "LOW"

    if ai >= 0.70:
        return "AI-generated Phishing", "HIGH"

    if human >= 0.65:
        return "Human-written Phishing", "HIGH"

    if max(human, ai) >= 0.40:
        return "Suspicious – Needs Review", "MEDIUM"

    
    return "Likely Legitimate", "LOW"



st.markdown("""
<div>
    <div class="app-title">FraudLens</div>
    <div class="app-subtitle">
        AI-Generated Fraud Content Detection · Offline · Analyst-Assist System
    </div>
</div>
<hr style="margin:18px 0">
""", unsafe_allow_html=True)


left, right = st.columns([1.7, 1])

with left:
    st.markdown("### Email Content")
    email_text = st.text_area(
        "Email Content",
        height=280,
        placeholder="Paste the full email message here for analysis…",
        label_visibility="collapsed"
    )
    analyze = st.button("Analyze Email", use_container_width=True)

with right:
    if analyze and email_text.strip():
        probs = predict(email_text)
        label, risk = decide_label(probs)

     
        st.markdown('<div class="card">', unsafe_allow_html=True)
        st.markdown("### Prediction Result")
        st.markdown(f"**{label}**")

        if risk == "HIGH":
            st.markdown("<span class='badge-high'>HIGH RISK</span>", unsafe_allow_html=True)
        elif risk == "MEDIUM":
            st.markdown("<span class='badge-medium'>MEDIUM RISK</span>", unsafe_allow_html=True)
        else:
            st.markdown("<span class='badge-low'>LOW RISK</span>", unsafe_allow_html=True)
        st.markdown("</div>", unsafe_allow_html=True)

        
        st.markdown('<div class="card">', unsafe_allow_html=True)
        st.markdown("### Model Confidence")
        st.progress(probs[0])
        st.caption(f"Legitimate Email — {probs[0]:.2f}")
        st.progress(probs[1])
        st.caption(f"Human Phishing — {probs[1]:.2f}")
        st.progress(probs[2])
        st.caption(f"AI-Generated Phishing — {probs[2]:.2f}")
        st.markdown("</div>", unsafe_allow_html=True)

        st.markdown('<div class="card">', unsafe_allow_html=True)
        st.markdown("### Explanation")

        reasons = []
        t = email_text.lower()

        if "urgent" in t or "immediately" in t:
            reasons.append("Urgent or coercive language detected")
        if "verify" in t or "confirm" in t:
            reasons.append("Request for account verification present")
        if probs[2] > 0.75:
            reasons.append("Highly structured language consistent with AI-generated content")
        if not reasons:
            reasons.append("No strong phishing indicators detected")

        for r in reasons:
            st.markdown(f"<div class='explain'>• {r}</div>", unsafe_allow_html=True)

        st.markdown("</div>", unsafe_allow_html=True)

    else:
        st.markdown('<div class="card">', unsafe_allow_html=True)
        st.markdown("### Awaiting Analysis")
        st.caption(
            "Paste an email on the left and click **Analyze Email** to receive a risk assessment."
        )
        st.markdown("</div>", unsafe_allow_html=True)


st.markdown(
    "<div class='footer'>FraudLens · Internal Fraud Prevention Platform · Hack-o-Hire Submission</div>",
    unsafe_allow_html=True
)
